
lexiconeditor

Author: Jan Dähne <https://www.quadro-system.de>
Copyright 2020

Official Documentation: https://www.quadro-system.de/modx-extras/lexiconeditor/

Bugs and Feature Requests: https://github.com/jdaehne/LexiconEditor

Questions: http://forums.modx.com
