Changelog for lexiconeditor

LexiconEditor 1.0.1
---------------------------------
+ Fix Github link in readme
+ Fix processor-paths for MODX3 (Thanx to sebastian-marinescu) (#5)

LexiconEditor 1.0.0
---------------------------------
+ Initial Version
