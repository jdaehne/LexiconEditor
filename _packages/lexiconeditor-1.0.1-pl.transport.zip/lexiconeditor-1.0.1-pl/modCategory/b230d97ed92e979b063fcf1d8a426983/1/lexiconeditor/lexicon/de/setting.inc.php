<?php
/**
 * Setting Lexicon Entries for LexiconEditor
 *
 * @package LexiconEditor
 * @subpackage lexicon
 */
$_lang['setting_lexiconeditor.namespace'] = 'Namespace';
$_lang['setting_lexiconeditor.namespace_desc'] = 'Namespace der bearbeitet werden soll.';
